# HandPose Estimation
# Dominic Langmesser and Matthew Sanchez
# VGG_colab is our main project notebook please run this 
# ResNet notebook is just to show our progress and failure, along with customDataset.py